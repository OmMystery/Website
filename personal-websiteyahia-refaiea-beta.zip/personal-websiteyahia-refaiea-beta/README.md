# Personal Website - Yahia Refaiea [Beta]

A Pen created on CodePen.io. Original URL: [https://codepen.io/Om-Mistry/pen/LYqRmPR](https://codepen.io/Om-Mistry/pen/LYqRmPR).

A 21 years old interaction designer who grows up in a small town in Syria.